#include<stdio.h>
/*The definition of Board function.this function shows the board of game.*/
char Board(char l[6][6]) {
	int i, j, k;
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			l[i][j] = '.';
		}
	}
	for (k = 1; k <= 3; k++) {
		printf("\t%d", k);
	}
	printf("\t|\t");
	for (k = 4; k <= 6; k++) {
		printf("%d\t", k);
	}
	printf("\n");
	for (i = 0; i <= 2; i++) {
		printf("%d\t", (i + 1));
		for (j = 0; j <= 2; j++) {
			printf("%c\t", l[i][j]);
		}
		printf("|\t");
		for (j = 3; j <= 5; j++) {
			printf("%c\t", l[i][j]);
		}
		printf("\n\n");
	}
	for (k = 0; k <= 3; k++) {
		printf("--\t");
	}
	printf("       ");
	for (k = 6; k <= 8; k++) {
		printf("--\t");
	}
	printf("\n\n");
	for (i = 3; i <= 5; i++) {
		printf("%d\t", (i + 1));
		for (j = 0; j <= 2; j++) {
			printf("%c\t", l[i][j]);
		}
		printf("|\t");
		for (j = 3; j <= 5; j++) {
			printf("%c\t", l[i][j]);
		}
		printf("\n\n");
	}
}