#include<stdio.h>
/*The definition of rotation function:*/
char rotation(char l[][6]) {
	int i, j;
	int sn;/*'sn' is the number of the chosen square.*/
	char d;/*'d' is a chararcter for showing the direction.*/
	printf("Choose one of the 4 squares:");
	scanf("%d", &sn);
	while ((sn <= 0) || (sn > 4)) {
		printf("The entered number is invalid.choose a number from 1 to 4:");
		scanf("%d", &sn);
	}
	printf("Choose your direction for the rotation.'+' is for clockwise rotation and'-' is for counter clockwise rotation:\n");
	scanf(" %c", &d);
	while ((d != '-') && (d != '+')) {
		printf("The entered direction is invalid. please choose one of the '-' or '+'");
		scanf(" %c", &d);
	}
	int m;/*'m' is a dummy variable for rotation.*/
	char t[3][3], tt[3][3];/*'t'and 'tt' are dummy arrays for rotation.*/
						   /*square 1 clockwise rotation:*/
	if ((d == '+') && (sn == 1)) {
		for (i = 0; i < 3; i++) {
			for (j = 3; j < 6; j++) {
				t[i][j - 3] = l[i][j];
			}
		}
		for (i = 0; i < 3; i++) {
			j = 0;
			m = 2;
			while ((j < 3) && (m >= 0)) {
				tt[i][j] = t[m][i];
				j++;
				m--;
			}
		}
		for (i = 0; i < 3; i++) {
			for (j = 3; j < 6; j++) {
				l[i][j] = tt[i][j - 3];
			}
		}
		system("cls");
		Updated_board(l);
	}
	/*square 1 counter clockwise rotation:*/
	if ((d == '-') && (sn == 1)) {
		for (i = 0; i < 3; i++) {
			for (j = 3; j < 6; j++) {
				t[i][j - 3] = l[i][j];
			}
		}
		i = 0;
		j = 2;
		while ((i < 3) && (j >= 0)) {
			for (m = 0; m < 3; m++) {
				tt[i][m] = t[m][j];
			}
			i++;
			j--;
		}
		for (i = 0; i < 3; i++) {
			for (j = 3; j < 6; j++) {
				l[i][j] = tt[i][j - 3];
			}
		}
		system("cls");
		Updated_board(l);
	}
	/*square 2 clockwise rotation:*/
	if ((d == '+') && (sn == 2)) {
		for (i = 0; i < 3; i++) {
			for (j = 0; j < 3; j++) {
				t[i][j] = l[i][j];
			}
		}
		for (i = 0; i < 3; i++) {
			j = 0;
			m = 2;
			while ((j < 3) && (m >= 0)) {
				tt[i][j] = t[m][i];
				j++;
				m--;
			}
		}
		for (i = 0; i < 3; i++) {
			for (j = 0; j < 3; j++) {
				l[i][j] = tt[i][j];
			}
		}
		system("cls");
		Updated_board(l);
	}
	/*square 2 counter clockwise rotation:*/
	if ((d == '-') && (sn == 2)) {
		for (i = 0; i < 3; i++) {
			for (j = 0; j < 3; j++) {
				t[i][j] = l[i][j];
			}
		}
		i = 0;
		j = 2;
		while ((i < 3) && (j >= 0)) {
			for (m = 0; m < 3; m++) {
				tt[i][m] = t[m][j];
			}
			i++;
			j--;
		}
		for (i = 0; i < 3; i++) {
			for (j = 0; j < 3; j++) {
				l[i][j] = tt[i][j];
			}
		}
		system("cls");
		Updated_board(l);
	}
	/*square 3 clockwise rotation:*/
	if ((d == '+') && (sn == 3)) {
		for (i = 3; i < 6; i++) {
			for (j = 0; j < 3; j++) {
				t[i - 3][j] = l[i][j];
			}
		}
		for (i = 0; i < 3; i++) {
			j = 0;
			m = 2;
			while ((j < 3) && (m >= 0)) {
				tt[i][j] = t[m][i];
				j++;
				m--;
			}
		}
		for (i = 3; i < 6; i++) {
			for (j = 0; j < 3; j++) {
				l[i][j] = tt[i - 3][j];
			}
		}
		system("cls");
		Updated_board(l);
	}
	/*square 3 counter clockwise rotation:*/
	if ((d == '-') && (sn == 3)) {
		for (i = 3; i < 6; i++) {
			for (j = 0; j < 3; j++) {
				t[i - 3][j] = l[i][j];
			}
		}
		i = 0;
		j = 2;
		while ((i < 3) && (j >= 0)) {
			for (m = 0; m < 3; m++) {
				tt[i][m] = t[m][j];
			}
			i++;
			j--;
		}
		for (i = 3; i < 6; i++) {
			for (j = 0; j < 3; j++) {
				l[i][j] = tt[i - 3][j];
			}
		}
		system("cls");
		Updated_board(l);
	}
	/*square 4 clockwise rotation:*/
	if ((d == '+') && (sn == 4)) {
		for (i = 3; i < 6; i++) {
			for (j = 3; j < 6; j++) {
				t[i - 3][j - 3] = l[i][j];
			}
		}
		for (i = 0; i < 3; i++) {
			j = 0;
			m = 2;
			while ((j < 3) && (m >= 0)) {
				tt[i][j] = t[m][i];
				j++;
				m--;
			}
		}
		for (i = 3; i < 6; i++) {
			for (j = 3; j < 6; j++) {
				l[i][j] = tt[i - 3][j - 3];
			}
		}
		system("cls");
		Updated_board(l);
	}
	/*square 4 counter clockwise rotation:*/
	if ((d == '-') && (sn == 4)) {
		for (i = 3; i < 6; i++) {
			for (j = 3; j < 6; j++) {
				t[i - 3][j - 3] = l[i][j];
			}
		}
		i = 0;
		j = 2;
		while ((i < 3) && (j >= 0)) {
			for (m = 0; m < 3; m++) {
				tt[i][m] = t[m][j];
			}
			i++;
			j--;
		}
		for (i = 3; i < 6; i++) {
			for (j = 3; j < 6; j++) {
				l[i][j] = tt[i - 3][j - 3];
			}
		}
		system("cls");
		Updated_board(l);
	}
}