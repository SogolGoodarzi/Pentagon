#include<stdio.h>
/*The definition of L_recognition function:*/
char L_recognition(char l[][6]) {
	int i, j;
	char state;
	int countw = 0, countb = 0;
	state = 'b';/*evaluation for 'black' color.*/
				/*horizontal'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((l[i][j] == state)) {
				if ((l[i][j + 1] == state) && (l[i][j + 2] == state) && (l[i][j + 3] == state)) {
					if ((l[i + 1][j + 3] == state) || (l[i - 1][j + 3] == state)) {
						countb++;
					}
				}
				if ((l[i][j - 1] == state) && (l[i][j - 2] == state) && (l[i][j - 3] == state)) {
					if ((l[i + 1][j - 3] == state) || (l[i - 1][j - 3] == state)) {
						countb++;
					}
				}
			}
		}
	}
	/*vertical'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((l[i][j] == state)) {
				if ((l[i + 1][j] == state) && (l[i + 2][j] == state) && (l[i + 3][j] == state)) {
					if ((l[i + 3][j - 1] == state) || (l[i + 3][j + 1] == state)) {
						countb++;
					}
				}
				if ((l[i - 1][j] == state) && (l[i - 2][j] == state) && (l[i - 3][j] == state)) {
					if ((l[i - 3][j - 1] == state) || (l[i - 3][j + 1] == state)) {
						countb++;
					}
				}
			}
		}
	}
	/*sidle'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((l[i][j] == state)) {
				if ((l[i + 1][j + 1] == state) && (l[i + 2][j + 2] == state) && (l[i + 3][j + 3] == state)) {
					if ((l[i + 2][j + 4] == state) || (l[i + 4][j + 2] == state)) {
						countb++;
					}
				}
				if ((l[i - 1][j - 1] == state) && (l[i - 2][j - 2] == state) && (l[i - 3][j - 3] == state)) {
					if ((l[i - 4][j - 2] == state) || (l[i - 2][j - 4] == state)) {
						countb++;
					}
				}
			}
		}
	}
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((l[i][j] == state)) {
				if ((l[i + 1][j - 1] == state) && (l[i + 2][j - 2] == state) && (l[i + 3][j - 3] == state)) {
					if ((l[i + 2][j - 4] == state) || (l[i + 4][j - 2] == state)) {
						countb++;
					}
				}
				if ((l[i - 1][j + 1] == state) && (l[i - 2][j + 2] == state) && (l[i - 3][j + 3] == state)) {
					if ((l[i - 2][j + 4] == state) || ((l[i - 4][j + 2] == state))) {
						countb++;
					}
				}
			}
		}
	}
	state = 'w';/*evaluation for 'white' color.*/
				/*horizontal'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((l[i][j] == state)) {
				if ((l[i][j + 1] == state) && (l[i][j + 2] == state) && (l[i][j + 3] == state)) {
					if ((l[i + 1][j + 3] == state) || (l[i - 1][j + 3] == state)) {
						countw++;
					}
				}
				if ((l[i][j - 1] == state) && (l[i][j - 2] == state) && (l[i][j - 3] == state)) {
					if ((l[i + 1][j - 3] == state) || (l[i - 1][j - 3] == state)) {
						countw++;
					}
				}
			}
		}
	}
	/*vertical'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((l[i][j] == state)) {
				if ((l[i + 1][j] == state) && (l[i + 2][j] == state) && (l[i + 3][j] == state)) {
					if ((l[i + 3][j - 1] == state) || (l[i + 3][j + 1] == state)) {
						countw++;
					}
				}
				if ((l[i - 1][j] == state) && (l[i - 2][j] == state) && (l[i - 3][j] == state)) {
					if ((l[i - 3][j - 1] == state) || (l[i - 3][j + 1] == state)) {
						countw++;
					}
				}
			}
		}
	}
	/*sidle'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((l[i][j] == state)) {
				if ((l[i + 1][j + 1] == state) && (l[i + 2][j + 2] == state) && (l[i + 3][j + 3] == state)) {
					if ((l[i + 2][j + 4] == state) || (l[i + 4][j + 2] == state)) {
						countw++;
					}
				}
				if ((l[i - 1][j - 1] == state) && (l[i - 2][j - 2] == state) && (l[i - 3][j - 3] == state)) {
					if ((l[i - 4][j - 2] == state) || (l[i - 2][j - 4] == state)) {
						countw++;
					}
				}
			}
		}
	}
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((l[i][j] == state)) {
				if ((l[i + 1][j - 1] == state) && (l[i + 2][j - 2] == state) && (l[i + 3][j - 3] == state)) {
					if ((l[i + 2][j - 4] == state) || (l[i + 4][j - 2] == state)) {
						countw++;
					}
				}
				if ((l[i - 1][j + 1] == state) && (l[i - 2][j + 2] == state) && (l[i - 3][j + 3] == state)) {
					if ((l[i - 2][j + 4] == state) || ((l[i - 4][j + 2] == state))) {
						countw++;
					}
				}
			}
		}
	}
	if ((countb > countw)) {
		printf("*---Black player won the game!---*\n");
		exit(0);
	}
	if ((countw > countb)) {
		printf("*---White player won the game!---*\n");
		exit(0);
	}
	if ((countw != 0) && (countb != 0) && (countb == countw)) {
		printf("No winner!\n");
		exit(0);
	}
}