#include<stdio.h>
#include "Board.h" /*a function for showing the board.*/
#include "Updated_board.h"/*a function for showing the updated board.*/
#include "rotation.h"/*a function for showing anf doing the rotation.*/
#include "L_recognition.h"/*a function for recognizing the state of 'L' for balls.*/
int main() {
	int k, p, i, j;/*'k' is the counter for the number of balls and 'p' is the position of the balls.*/
	char l[6][6], state;
	Board(l);
	for (k = 1; k <= 36; k++) {
		if ((k % 2) != 0) {
			state = 'b';
			printf("Black players turn:");
		}
		else if ((k % 2) == 0) {
			state = 'w';
			printf("White players turn:");
		}
		scanf("%d", &p);
		/*For invalid inputs.*/
		while ((p / 100) != 0) {
			printf("The entered number is invalid.Try a two_digit number:");
			scanf("%d", &p);
		}
		i = (p / 10) - 1;
		j = (p % 10) - 1;
		while ((i > 5) || (j > 5) || (p < 0) || (i < 0) || (j < 0)) {
			printf("The entered number is invalid.Try another number:");
			scanf("%d", &p);
			i = (p / 10) - 1;
			j = (p % 10) - 1;
		}
		while (l[i][j] != '.') {/*When the chosen position is full.*/
			printf("The chosen position is not empty.please try another position.");
			scanf("%d", &p);
			i = (p / 10) - 1;
			j = (p % 10) - 1;
			while ((i > 5) || (j > 5) || (p < 0) || (i < 0) || (j < 0)) {
				printf("The entered number is invalid.Try another number:");
				scanf("%d", &p);
				i = (p / 10) - 1;
				j = (p % 10) - 1;
			}
		}
		if (state == 'b') {
			l[i][j] = 'b';
		}
		else if (state == 'w') {
			l[i][j] = 'w';
		}
		system("cls");
		Updated_board(l);
		/*rotation*/
		rotation(l);
		/*recognition of 'L':*/
		L_recognition(l);
	}/*The end of first 'for'*/
	printf("No winner.");
}/*The end of main*/
