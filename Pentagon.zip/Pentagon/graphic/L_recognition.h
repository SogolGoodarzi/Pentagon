#include<stdio.h>
#include"graphics.h"
void L_recognition(char p[][6], char state) {
	int countb = 0, countw = 0, i, j;
	state = 'b';/*evaluation for 'black' color.*/
				/*vertical'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((p[i][j] == state)) {
				if ((p[i][j + 1] == state) && (p[i][j + 2] == state) && (p[i][j + 3] == state)) {
					if ((p[i + 1][j + 3] == state) || (p[i - 1][j + 3] == state)) {
						countb++;
					}
				}
				if ((p[i][j - 1] == state) && (p[i][j - 2] == state) && (p[i][j - 3] == state)) {
					if ((p[i + 1][j - 3] == state) || (p[i - 1][j - 3] == state)) {
						countb++;
					}
				}
			}
		}
	}
	/*horizontal'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((p[i][j] == state)) {
				if ((p[i + 1][j] == state) && (p[i + 2][j] == state) && (p[i + 3][j] == state)) {
					if ((p[i + 3][j - 1] == state) || (p[i + 3][j + 1] == state)) {
						countb++;
					}
				}
				if ((p[i - 1][j] == state) && (p[i - 2][j] == state) && (p[i - 3][j] == state)) {
					if ((p[i - 3][j - 1] == state) || (p[i - 3][j + 1] == state)) {
						countb++;
					}
				}
			}
		}
	}
	/*sidle'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((p[i][j] == state)) {
				if ((p[i + 1][j + 1] == state) && (p[i + 2][j + 2] == state) && (p[i + 3][j + 3] == state)) {
					if ((p[i + 2][j + 4] == state) || (p[i + 4][j + 2] == state)) {
						countb++;
					}
				}
				if ((p[i - 1][j - 1] == state) && (p[i - 2][j - 2] == state) && (p[i - 3][j - 3] == state)) {
					if ((p[i - 4][j - 2] == state) || (p[i - 2][j - 4] == state)) {
						countb++;
					}
				}
			}
		}
	}
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((p[i][j] == state)) {
				if ((p[i + 1][j - 1] == state) && (p[i + 2][j - 2] == state) && (p[i + 3][j - 3] == state)) {
					if ((p[i + 2][j - 4] == state) || (p[i + 4][j - 2] == state)) {
						countb++;
					}
				}
				if ((p[i - 1][j + 1] == state) && (p[i - 2][j + 2] == state) && (p[i - 3][j + 3] == state)) {
					if ((p[i - 2][j + 4] == state) || ((p[i - 4][j + 2] == state))) {
						countb++;
					}
				}
			}
		}
	}
	state = 'e';/*evaluation for 'white' color.*/
				/*vertical'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((p[i][j] == state)) {
				if ((p[i][j + 1] == state) && (p[i][j + 2] == state) && (p[i][j + 3] == state)) {
					if ((p[i + 1][j + 3] == state) || (p[i - 1][j + 3] == state)) {
						countw++;
					}
				}
				if ((p[i][j - 1] == state) && (p[i][j - 2] == state) && (p[i][j - 3] == state)) {
					if ((p[i + 1][j - 3] == state) || (p[i - 1][j - 3] == state)) {
						countw++;
					}
				}
			}
		}
	}
	/*horizontal'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((p[i][j] == state)) {
				if ((p[i + 1][j] == state) && (p[i + 2][j] == state) && (p[i + 3][j] == state)) {
					if ((p[i + 3][j - 1] == state) || (p[i + 3][j + 1] == state)) {
						countw++;
					}
				}
				if ((p[i - 1][j] == state) && (p[i - 2][j] == state) && (p[i - 3][j] == state)) {
					if ((p[i - 3][j - 1] == state) || (p[i - 3][j + 1] == state)) {
						countw++;
					}
				}
			}
		}
	}
	/*sidle'L'*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((p[i][j] == state)) {
				if ((p[i + 1][j + 1] == state) && (p[i + 2][j + 2] == state) && (p[i + 3][j + 3] == state)) {
					if ((p[i + 2][j + 4] == state) || (p[i + 4][j + 2] == state)) {
						countw++;
					}
				}
				if ((p[i - 1][j - 1] == state) && (p[i - 2][j - 2] == state) && (p[i - 3][j - 3] == state)) {
					if ((p[i - 4][j - 2] == state) || (p[i - 2][j - 4] == state)) {
						countw++;
					}
				}
			}
		}
	}
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if ((p[i][j] == state)) {
				if ((p[i + 1][j - 1] == state) && (p[i + 2][j - 2] == state) && (p[i + 3][j - 3] == state)) {
					if ((p[i + 2][j - 4] == state) || (p[i + 4][j - 2] == state)) {
						countw++;
					}
				}
				if ((p[i - 1][j + 1] == state) && (p[i - 2][j + 2] == state) && (p[i - 3][j + 3] == state)) {
					if ((p[i - 2][j + 4] == state) || ((p[i - 4][j + 2] == state))) {
						countw++;
					}
				}
			}
		}
	}
	if (countb>countw) {
		outtextxy(20, 680, "*---Black player won the game!---*");
		delay(5000);
		closegraph();
	}
	if (countw>countb) {
		outtextxy(20, 680, "*---White player won the game!---*");
		delay(5000);
		closegraph();
	}
	if ((countw != 0) && (countb != 0) && (countb == countw)) {
		outtextxy(20, 680, "No winner!");
		delay(5000);
		closegraph();
	}
}