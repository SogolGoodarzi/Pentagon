#include<stdio.h>
#include"graphics.h"
void Board(int l, int u, int r, int d, char p[][6]) {
	int wid = ALL_WINDOWS;
	initwindow(650, 800, "PENTAGOL");
	char ch;
	int x, y, i, j;
	setfillstyle(1, 4);
	rectangle(10, 10, 630, 630);
	floodfill(30, 30, 15);
	setcolor(15);
	rectangle(20, 20, 620, 620);
	line(20, 320, 620, 320);
	line(320, 20, 320, 620);
	x = 70, y = 70;
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if (p[i][j] == '.') {
				setcolor(15);
				circle(x, y, 40);
			}
			if (p[i][j] == 'b') {
				setcolor(0);
				setfillstyle(1, 0);
				fillellipse(i * 100 + 70, j * 100 + 70, 40, 40);
			}
			if (p[i][j] == 'e') {
				setcolor(15);
				setfillstyle(1, 15);
				fillellipse(i * 100 + 70, j * 100 + 70, 40, 40);
			}
			y = y + 100;
		}
		y = y - 600;
		x = x + 100;
	}
	setcolor(14);
}