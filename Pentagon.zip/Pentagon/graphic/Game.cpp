#include"graphics.h"
#include<stdio.h>
#include "Board.h"
#include "position.h"
#include "rotation.h"
#include "L_recognition.h"
void main() {
	int wid = ALL_WINDOWS;
	initwindow(650, 800);
	char ch,d1,sn,state, ch1 = 'c';/*'ch' is for the esc 'ch1' is for moving the yellow square,'sn' is square numbers and 'd1' is for the direction of the rotation.*/
	char p[6][6];/*The array for each position*/
	int l = 29, u = 29, r = 110, d = 110,i=0,j=0, ii = 0, jj = 0;/*l,u,r,d are the first coordinates.'i'&'j' is 'p's factors and 'ii'&'jj'are dummy variables for moving the square.*/
	int k;/*'k' is for counting the balls for evaluating the state of equallity*/
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			p[i][j] = '.';
		}
	}
	Board(l,u,r,d,p);
	for (k = 1; k <= 36; k++) {
		int l = 29, u = 29, r = 110, d = 110, i = 0, j = 0, ii = 0, jj = 0;
		rectangle(l, u, r, d);
		if ((k % 2) != 0) {
			state = 'b';
			outtextxy(20, 660, "Black players turn");
		}
		else if ((k % 2) == 0) {
			state = 'e';
			outtextxy(20, 660, "White players turn");
		}
		if (!kbhit()) {
			position(p, state);
			rotation(p);
			L_recognition(p, state);
		}/*end of if(kbhit)*/
		}/*end of the first for*/
		outtextxy(20, 680, "No winner!");
		while (1) {
			if (!kbhit()) {
				ch = getch();
				if ((int)ch == 27)
					exit(0);
			}
		}
	}/*end of main*/
