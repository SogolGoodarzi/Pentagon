#include<stdio.h>
#include"graphics.h"
void remove(int l, int u, int r, int d) {
	setcolor(4);
	rectangle(l, u, r, d);
	setcolor(14);
}
void position(char p[][6], char state) {
	int l = 29, u = 29, r = 110, d = 110, i = 0, j = 0, ii = 0, jj = 0;
	char ch1;
	ch1 = getch();/*choosing the position of a ball:*/
				  /*error for the wrong keys*/
	while ((ch1 != 'a') && (ch1 != 's') && (ch1 != 'd') && (ch1 != 'w') && (ch1 != 'f')) {
		outtextxy(20, 660, "can't move the square.please press one of the 'a','s','d','w','f'");
		ch1 = getch();
	}
	while ((ch1 == 'a') || (ch1 == 's') || (ch1 == 'd') || (ch1 == 'w')) {
		if ((ch1 == 'a') && (i>0)) {/*moving to the left*/
			ii = 1;
			i--;
			remove(l, u, r, d);
			l = l - 100 * ii;
			r = r - 100 * ii;
			rectangle(l, u, r, d);
		}
		if ((ch1 == 'd') && (i<5)) {/*moving to the right*/
			ii = 1;
			i++;
			remove(l, u, r, d);
			l = l + 100 * ii;
			r = r + 100 * ii;
			rectangle(l, u, r, d);
		}
		if ((ch1 == 's') && (j<5)) {/*moving dawn*/
			jj = 1;
			j++;
			remove(l, u, r, d);
			u = u + 100 * jj;
			d = d + 100 * jj;
			rectangle(l, u, r, d);
		}
		if ((ch1 == 'w') && (j>0)) {/*moving up*/
			jj = 1;
			j--;
			remove(l, u, r, d);
			u = u - 100 * jj;
			d = d - 100 * jj;
			rectangle(l, u, r, d);
		}
		ch1 = getch();
	}
	while (ch1 != 'f') {
		outtextxy(20, 660, "For putting the ball press 'f'.");
		ch1 = getch();
	}
	if (ch1 == 'f') {/*putting the ball in the chosen position*/
		while ((ch1 == 'f') && (p[i][j] != '.')) {
			outtextxy(20, 660, "The chosen position is not empty.try another position.");
			ch1 = getch();
			while ((ch1 != 'a') && (ch1 != 's') && (ch1 != 'd') && (ch1 != 'w') && (ch1 != 'f')) {
				outtextxy(20, 660, "can't move the square.please press one of the 'a','s','d','w','f'");
				ch1 = getch();
			}
			while ((ch1 == 'a') || (ch1 == 's') || (ch1 == 'd') || (ch1 == 'w')) {
				if (ch1 == 'a') {/*moving to the left*/
					ii = 1;
					i--;
					remove(l, u, r, d);
					l = l - 100 * ii;
					r = r - 100 * ii;
					rectangle(l, u, r, d);
				}
				if (ch1 == 'd') {/*moving to the right*/
					ii = 1;
					i++;
					remove(l, u, r, d);
					l = l + 100 * ii;
					r = r + 100 * ii;
					rectangle(l, u, r, d);
				}
				if (ch1 == 's') {/*moving dawn*/
					jj = 1;
					j++;
					remove(l, u, r, d);
					u = u + 100 * jj;
					d = d + 100 * jj;
					rectangle(l, u, r, d);
				}
				if (ch1 == 'w') {/*moving up*/
					jj = 1;
					j--;
					remove(l, u, r, d);
					u = u - 100 * jj;
					d = d - 100 * jj;
					rectangle(l, u, r, d);
				}
				ch1 = getch();
			}
			while (ch1 != 'f') {
				outtextxy(20, 660, "For putting the ball press 'f'.");
				ch1 = getch();
			}
		}
		p[i][j] = state;
		if (p[i][j] == 'b') {
			setcolor(0);
			setfillstyle(1, 0);
			fillellipse(i * 100 + 70, j * 100 + 70, 40, 40);
		}
		else if (p[i][j] == 'e') {
			setcolor(15);
			setfillstyle(1, 15);
			fillellipse(i * 100 + 70, j * 100 + 70, 40, 40);
		}
		setcolor(4);
		rectangle(l, u, r, d);
		setcolor(14);
		rectangle(29, 29, 110, 110);
	}
}