#include<stdio.h>
#include"graphics.h"
void rotation(char p[][6]) {
	int i, j;
	char sn, d1;
	int l = 29, u = 29, r = 110, d = 110;
	outtextxy(20, 680, "choose a number for squares:");
	sn = getch();
	while ((sn != '1') && (sn != '2') && (sn != '3') && (sn != '4')) {
		outtextxy(20, 680, "The entered number is invalid.choose a number from 1 to 4:");
		sn = getch();
	}
	outtextxy(20, 700, "choose a direction for rotation:");
	d1 = getch();
	while ((d1 != '+') && (d1 != '-')) {
		outtextxy(20, 700, "The entered direction is invalid. please choose one of the '-' or '+'");
		d1 = getch();
	}
	int m;/*'m' is a dummy variable for rotation.*/
	char t[3][3], tt[3][3];/*'t'and 'tt' are dummy arrays for rotation.*/
						   /*square 1 counter clockwise rotation:*/
	if ((d1 == '-') && (sn == '1')) {
		for (i = 3; i < 6; i++) {
			for (j = 0; j < 3; j++) {
				t[i - 3][j] = p[i][j];
			}
		}
		for (i = 0; i < 3; i++) {
			j = 0;
			m = 2;
			while ((j < 3) && (m >= 0)) {
				tt[i][j] = t[m][i];
				j++;
				m--;
			}
		}
		for (i = 3; i < 6; i++) {
			for (j = 0; j < 3; j++) {
				p[i][j] = tt[i - 3][j];
			}
		}
		closegraph();
		Board(l, u, r, d, p);
	}
	/*square 1 clockwise rotation:*/
	if ((d1 == '+') && (sn == '1')) {
		for (i = 3; i < 6; i++) {
			for (j = 0; j < 3; j++) {
				t[i - 3][j] = p[i][j];
			}
		}
		i = 0;
		j = 2;
		while ((i < 3) && (j >= 0)) {
			for (m = 0; m < 3; m++) {
				tt[i][m] = t[m][j];
			}
			i++;
			j--;
		}
		for (i = 3; i < 6; i++) {
			for (j = 0; j < 3; j++) {
				p[i][j] = tt[i - 3][j];
			}
		}
		closegraph();
		Board(l, u, r, d, p);
	}
	/*square 2 counter clockwise rotation:*/
	if ((d1 == '-') && (sn == '2')) {
		for (i = 0; i < 3; i++) {
			for (j = 0; j < 3; j++) {
				t[i][j] = p[i][j];
			}
		}
		for (i = 0; i < 3; i++) {
			j = 0;
			m = 2;
			while ((j < 3) && (m >= 0)) {
				tt[i][j] = t[m][i];
				j++;
				m--;
			}
		}
		for (i = 0; i < 3; i++) {
			for (j = 0; j < 3; j++) {
				p[i][j] = tt[i][j];
			}
		}
		closegraph();
		Board(l, u, r, d, p);
	}
	/*square 2 clockwise rotation:*/
	if ((d1 == '+') && (sn == '2')) {
		for (i = 0; i < 3; i++) {
			for (j = 0; j < 3; j++) {
				t[i][j] = p[i][j];
			}
		}
		i = 0;
		j = 2;
		while ((i < 3) && (j >= 0)) {
			for (m = 0; m < 3; m++) {
				tt[i][m] = t[m][j];
			}
			i++;
			j--;
		}
		for (i = 0; i < 3; i++) {
			for (j = 0; j < 3; j++) {
				p[i][j] = tt[i][j];
			}
		}
		closegraph();
		Board(l, u, r, d, p);
	}
	/*square 3 counter clockwise rotation:*/
	if ((d1 == '-') && (sn == '3')) {
		for (i = 0; i < 3; i++) {
			for (j = 3; j < 6; j++) {
				t[i][j - 3] = p[i][j];
			}
		}
		for (i = 0; i < 3; i++) {
			j = 0;
			m = 2;
			while ((j < 3) && (m >= 0)) {
				tt[i][j] = t[m][i];
				j++;
				m--;
			}
		}
		for (i = 0; i < 3; i++) {
			for (j = 3; j < 6; j++) {
				p[i][j] = tt[i][j - 3];
			}
		}
		closegraph();
		Board(l, u, r, d, p);
	}
	/*square 3 clockwise rotation:*/
	if ((d1 == '+') && (sn == '3')) {
		for (i = 0; i < 3; i++) {
			for (j = 3; j < 6; j++) {
				t[i][j - 3] = p[i][j];
			}
		}
		i = 0;
		j = 2;
		while ((i < 3) && (j >= 0)) {
			for (m = 0; m < 3; m++) {
				tt[i][m] = t[m][j];
			}
			i++;
			j--;
		}
		for (i = 0; i < 3; i++) {
			for (j = 3; j < 6; j++) {
				p[i][j] = tt[i][j - 3];
			}
		}
		closegraph();
		Board(l, u, r, d, p);
	}
	/*square 4 counter clockwise rotation:*/
	if ((d1 == '-') && (sn == '4')) {
		for (i = 3; i < 6; i++) {
			for (j = 3; j < 6; j++) {
				t[i - 3][j - 3] = p[i][j];
			}
		}
		for (i = 0; i < 3; i++) {
			j = 0;
			m = 2;
			while ((j < 3) && (m >= 0)) {
				tt[i][j] = t[m][i];
				j++;
				m--;
			}
		}
		for (i = 3; i < 6; i++) {
			for (j = 3; j < 6; j++) {
				p[i][j] = tt[i - 3][j - 3];
			}
		}
		closegraph();
		Board(l, u, r, d, p);
	}
	/*square 4 clockwise rotation:*/
	if ((d1 == '+') && (sn == '4')) {
		for (i = 3; i < 6; i++) {
			for (j = 3; j < 6; j++) {
				t[i - 3][j - 3] = p[i][j];
			}
		}
		i = 0;
		j = 2;
		while ((i < 3) && (j >= 0)) {
			for (m = 0; m < 3; m++) {
				tt[i][m] = t[m][j];
			}
			i++;
			j--;
		}
		for (i = 3; i < 6; i++) {
			for (j = 3; j < 6; j++) {
				p[i][j] = tt[i - 3][j - 3];
			}
		}
		closegraph();
		Board(l, u, r, d, p);
	}
}